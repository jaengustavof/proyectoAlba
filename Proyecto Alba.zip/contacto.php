<?php

   use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
#verifica que se haya enviado el formulario
if($_POST){

    #para poder utlizar el php mailer


  #controlamos que todos los campos existan y no est'en vacíos
   if((isset($_POST['nombreContacto']) && !empty($_POST['nombreContacto'])) && (isset($_POST['apellidoContacto']) && !empty($_POST['apellidoContacto'])) && (isset($_POST['emailContacto']) && !empty($_POST['emailContacto'])) && (isset($_POST['asuntoContacto']) && !empty($_POST['asuntoContacto'])) && (isset($_POST['mensajeContacto']) && !empty($_POST['mensajeContacto']))){

       require 'includes/Exception.php';
        require 'includes/PHPMailer.php';
        require 'includes/SMTP.php';

        $nombre = $_POST['nombreContacto'];
        $apellido = $_POST['apellidoContacto'];
        $email = $_POST['emailContacto'];
        $asunto = $_POST['asuntoContacto'];
        $mensaje = $_POST['mensajeContacto'];

        // Crea el Objeto
        $correoElectronico = new PHPMailer;
                // Emisor
        $correoElectronico->setFrom('info@jaenwebdesign.com', 'Contacto Alba');
                // Receptor
                $correoElectronico->addAddress('info@jaenwebdesign.com', 'Alba');
                // Asunto
                $correoElectronico->Subject = $asunto;
                // Mensaje
                    // $correoElectronico->msgHTML('Esto es una prueba de HTML: <a href="https://google.com">Ir a Google</a>');
                    // $correoElectronico->msgHTML(file_get_contents('assets/rsc/email_templates/index.html'), __DIR__);
                 $correoElectronico->msgHTML('El siguiente usuario se ha contactado a través del formulario de contacto<br><br> Nombre: '.$nombre.'<br> Apellido: '.$apellido.'<br> Email: '.$email.'<br> Asunto: '.$asunto.'<br> Mensaje: '.$mensaje);
                // Mensaje Alternativo (si no carga el anterior)
                $correoElectronico->AltBody = 'El SEGUNDO contenido que queramos';
                // Codificación de Caracteres
                $correoElectronico->CharSet = 'UTF-8';
                
                //Enviar Mensaje verificando errores
            
                      /*          
                              if (!$correoElectronico->send()){
                                  echo 'Error al enviar: '.$correoElectronico->ErrorInfo;
                              }else{
                                  echo '<div class="alert alert-success" role="alert">
                                    Mensaje enviado correctamente.
                                </div>';
                              }
*/
                        
    

    }else {

        echo 'erros';
        
    }


}

?>


<!DOCTYPE html>
<html lang="es">
    <head>
        <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content="Gustavo Jaén Vidal"><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content="Gustavo Jaén Vidal"><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content="jaengustavof@alumnos.cei.es"> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content="Si dispones de tiempo para educarle y atenderle, adopta un perro!! Si adoptas un perro en ALBA, lo recibirás con todas las garantías sanitarias y te ayudamos en su educación regalándote un curso básico de obediencia. Te asesoramos sobre cuál será tu mejor candidato."> <!--descripcion de la pagina web-->
        <meta name="keywords" content="Protectora de animales. Adopta un perro. Adopta un gato. Perros en adopción. Gatos en adopción. adoptar una mascota."> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content. --><!--<meta name="robots" content="Index, Follow">-->
        <!--<meta name="robots" content="Index, NoIndex"> para indexar el sitio-->
        <!--<meta name="robots" content="Follow, NoFollow">
            para que rastree o no los enlaces-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">



        <!-- ESTILOS -->
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
        <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css"><!--Swiper-->
         <link rel="stylesheet" href="vendor/animateCSS/animate.min.css"><!--Animate CSS-->

         <!--Google Fonts-->
        <link href="https://fonts.googleapis.com/css2?family=Arvo:wght@400;700&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="icon" tyoe="icon/png" href="favicon.png"> <!--va en la carpeta root. El favicon debe llamarse favicon.png. tiene que ser cuadrado. Mismo alto y ancho.-->

        <!--FontAwesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">

        
        
        <title>Asociación Alba : Protectora de animales en Madrid. Adopta a un perro</title>

    </head>
    <body>

        <div class="container">

        <nav id="navBarMobile">
              <i class="fas fa-bars menuHamb" onclick="desplegar()"></i>
        <!-- Vertical por CSS ver archivo -->
            <div id="menuMobile">
                <div onclick="cerrarMenu()">X</div>

                <ul>
                    <li>
                        <a href="index.html">Inicio</a>
                    </li>
                    <li>
                        <a href="nosotros.html">Sobre Nosotros</a>
                    </li>
                    <li>
                        <a href="perros.html">Perros en Adopción</a>
                    </li>
                    <li>
                        <a href="#">Gatos en Adopción</a>
                    </li>
                    <li>
                        <a href="https://albaonline.org/historico">Histórico</a>
                    </li>
                    <li>
                        <a href="contacto.html">Contacto</a>
                    </li>
                    <li>
                        <a href="https://www.albaonline.org/blog/category/educacion-canina/">Blog</a>
                    </li>
                </ul>
            </div>
         </nav>
         
            
            <header class="contactarAlba">
                
                <nav id="navbar">
                    <div class="logo">
                        <img src="assets/rsc/img/logoAlba1.png" alt="">    
                    </div>
                    <div class="menu">
                        <div class="social">
                            <div><i class="fab fa-facebook"></i></div>
                            <div><i class="fab fa-youtube"></i></div>
                            <div><i class="fab fa-twitter-square"></i></div>
                            <div><i class="fab fa-instagram"></i></div>
                            <div><i class="fab fa-gratipay"></i></div>
                        </div>
                        <div class="enlaces">
                            <a href="index.html" class="bordeD">Inicio</a>
                            <a href="nosotros.html" class="bordeD">Sobre Nosotros</a>
                            <a href="perros.html" class="bordeD">Perros en Adopción</a>
                            <a href="#" class="bordeD">Gatos en Adopción</a>
                            <a href="https://albaonline.org/historico" class="bordeD">Histórico</a>
                            <a href="contacto.html" class="bordeD">Contacto</a>
                            <a href="https://www.albaonline.org/blog/category/educacion-canina/">Blog</a>
                        </div>
                    </div>
                    
                </nav>


            </header>
            
            <section class="contacto">
                
                <div class="formularioContacto">
                    <h2>Formulario de Contacto</h2>
                   <form action="" name="formuContact" method="POST" id="contactForm">
                        
                        <label for="nombreContacto">Nombre</label>
                        <input type="text" name="nombreContacto" placeholder="Nombre">

                        <label for="apellidoContacto">Apellido</label>
                        <input type="text" name="apellidoContacto" placeholder="Apellido">

                        <label for="emailContacto">Correo Electrónico</label>
                        <input type="text" name="emailContacto" placeholder="Correo Electrónico">

                        <label for="asuntoContacto">Asunto</label>
                        <input type="text" name="asuntoContacto" placeholder="Asunto">

                        <label for="mensajeContacto">Mensaje</label>
                        <textarea name="mensajeContacto" id="" cols="30" rows="10" placeholder="Escriba aquí su mensaje"></textarea>
                        
                        <button name="enviarFormulario">Enviar</button>

                    </form>
                    
                  

    
                </div>
            </section>
           
            <footer>
                <div>
                    <h5>Alba Online</h5>
                    <ul>
                        <li><a href="#">Sobre Nosotros</a></li>
                        <li><a href="#">Contacto</a></li>
                        <li><a href="#">Adopta un Perro</a></li>
                        <li><a href="#">Adopta un Gato</a></li>
                        <li><a href="#">Adoptados - Finales Felices</a></li>
                    </ul>
                </div>
              
               <div>
                    <h5>COLABORA</h5>
                    <ul>
                        <li><a href="#">Hazte Socio</a></li>
                        <li><a href="#">Hazte Padrino</a></li>
                        <li><a href="#">Hazte Colaborador</a></li>
                        <li><a href="#">Hazte Voluntario</a></li>
                        <li><a href="#">Hazte Patrocinador</a></li>
                    </ul>
                </div>

                <div>
                    <h5>CONDICIONES LEGALES</h5>
                    <ul>
                        <li><a href="#">Política de Cookies</a></li>
                        <li><a href="#">Aviso Legal</a></li>
                        <li><a href="#">Política de Privacidad</a></li>
                        <li><a href="#">Condiciones de Adcopción</a></li>
                        <li><a href="#">Nosotros</a></li>
                    </ul>
                </div>

                 <div>
                    <h5>BLOG/NOTICIAS/MEDIA</h5>
                    <ul>
                        <li><a href="#">Noticias</a></li>
                        <li><a href="#">Consejos</a></li>
                        <li><a href="#">Ayuntamientos</a></li>
                        <li><a href="#">Multimedia</a></li>
                        <li><a href="#">Galería de imágenes</a></li>
                    </ul>
                </div>
                
            </footer>

        </div>   


        <script type="text/javascript" src="vendor/jquery/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="vendor/jqueryUI/js/jquery-ui.min.js"></script>
         
        <script type="text/javascript" src="vendor/swiper/js/swiper.min.js"></script><!--ASI SE IMPLMENTA SWIPER-->
        <script type="text/javascript" src="assets/js/script.js"></script>

    <script>
       


                function desplegar(){
            document.getElementById('menuMobile').style.transform = 'translate(0%, 0%)';
        }

        function cerrarMenu(){
            document.getElementById('menuMobile').style.transform = 'translate(-100%, 0%)';
        }



  </script>
    </body>
</html>